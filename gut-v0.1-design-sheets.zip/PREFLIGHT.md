# Preflight report

Unfilled cells and unresolved references across all sheets.

## Unfilled cells (null)

- 04_golden_light_import:gl_reader.value  (row status: spike)
- 04_golden_light_import:gl_job_flesh.value.source_container  (row status: spike)
- 04_golden_light_import:gl_job_flesh.value.source_asset  (row status: spike)
- 04_golden_light_import:gl_job_membrane.value.source_container  (row status: spike)
- 04_golden_light_import:gl_job_membrane.value.source_asset  (row status: spike)
- 04_golden_light_import:gl_job_bone.value.source_container  (row status: spike)
- 04_golden_light_import:gl_job_bone.value.source_asset  (row status: spike)
- 04_golden_light_import:gl_job_marrow.value.source_container  (row status: spike)
- 04_golden_light_import:gl_job_marrow.value.source_asset  (row status: spike)
- 04_golden_light_import:gl_job_music.value.source_container  (row status: spike)
- 04_golden_light_import:gl_job_music.value.source_asset  (row status: spike)
- 04_golden_light_import:gl_rights.value  (row status: spike)
- 06_atmosphere:snd_ambient_mood.value.golden_light_job  (row status: verify)
- 08_one_click_flow:oc_listing.detail.license  (row status: draft)
- 08_one_click_flow:oc_listing.detail.remix_allowed  (row status: draft)

## References that do not resolve

- none

## Row status counts

- blocked: 1
- draft: 1
- filled: 54
- not-run: 9
- spike: 8
- to-generate: 6
- verify: 18

Unfilled cells: 15. Broken references: 0.
Build only when unfilled cells marked spike are resolved and verify rows are checked against the game.
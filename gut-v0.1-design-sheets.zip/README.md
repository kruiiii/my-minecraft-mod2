# The Gut: v0.1 design sheets (Minecraft Java 1.16.5 + Fabric, Golden Light secondary)

Golden Light is locally imported from the player's own installation. Nothing from it is uploaded, bundled or redistributed, and the mod is fully playable without it.

Sheets (the source of truth; change the sheet before the code):
01 dimension generation, 02 Gut Key and portal, 03 first join, 04 Golden Light import, 05 fallback textures, 06 atmosphere, 07 project structure, 08 one-click flow, 09 tests.

`python3 preflight.py` lists unfilled cells and broken references. Current result is in PREFLIGHT.md.

## Handoff to a coding agent on the PC
1. Connect to Melty with a fresh token (the one pasted earlier should be revoked).
2. Resolve the `spike` rows first: how to read Unity files (sheet 04 gl_reader), then the source assets for each import job. Use the Golden Light install on that PC.
3. Check every `verify` row against the real game and Fabric 1.16.5 before relying on it.
4. Generate the fallback PNGs and sounds.json (sheet 05, 06), build, run tests t1-t9, then one_click_check and publish through Melty.

import json,glob,os
sheets={os.path.basename(p)[:-5]:json.load(open(p)) for p in sorted(glob.glob("sheets/*.json"))}
ids={}
for n,s in sheets.items():
    for r in s["rows"]: ids.setdefault(r["id"],n)
def nulls(v,path):
    if v is None: yield path
    elif isinstance(v,dict):
        for k,x in v.items(): yield from nulls(x,path+"."+k)
    elif isinstance(v,list):
        for i,x in enumerate(v): yield from nulls(x,f"{path}[{i}]")
def refs(v,col):
    if col.startswith("ref_") or col in("golden_light_job",):
        for x in (v if isinstance(v,list) else [v]):
            if x is not None: yield x
    if isinstance(v,dict):
        for k,x in v.items():
            if k.startswith("ref_") or k=="golden_light_job":
                for y in (x if isinstance(x,list) else [x]):
                    if y is not None: yield y
out=["# Preflight report","","Unfilled cells and unresolved references across all sheets.","","## Unfilled cells (null)",""]
unf=0;bad=0;stat={}
for n,s in sheets.items():
    for r in s["rows"]:
        stat[r.get("status")]=stat.get(r.get("status"),0)+1
        for c in s["columns"]:
            if c=="id": continue
            for p in nulls(r.get(c),f"{n}:{r['id']}.{c}"):
                if c in s["optional_columns"] and p.count(".")==1: continue
                out.append(f"- {p}  (row status: {r['status']})"); unf+=1
out+=["","## References that do not resolve",""]
for n,s in sheets.items():
    for r in s["rows"]:
        for c in s["columns"]:
            for x in refs(r.get(c),c):
                if x not in ids and not str(x).startswith("minecraft:"):
                    out.append(f"- {n}:{r['id']}.{c} -> {x}"); bad+=1
if bad==0: out.append("- none")
out+=["","## Row status counts","",*[f"- {k}: {v}" for k,v in sorted(stat.items(),key=lambda x:str(x[0]))]]
out+=["",f"Unfilled cells: {unf}. Broken references: {bad}.","Build only when unfilled cells marked spike are resolved and verify rows are checked against the game."]
open("PREFLIGHT.md","w").write("\n".join(out)); print("\n".join(out))

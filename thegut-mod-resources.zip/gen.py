import json, os, random, zlib, struct
R="src/main/resources"
def w(path, obj):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    open(path,"w").write(json.dumps(obj,indent=2) if not isinstance(obj,str) else obj)
def png(path,wd,ht,px):
    raw=b"".join(b"\x00"+b"".join(bytes(px(x,y)) for x in range(wd)) for y in range(ht))
    def ch(t,d): c=struct.pack(">I",len(d))+t+d; return c+struct.pack(">I",zlib.crc32(t+d)&0xffffffff)
    os.makedirs(os.path.dirname(path),exist_ok=True)
    open(path,"wb").write(b"\x89PNG\r\n\x1a\n"+ch(b"IHDR",struct.pack(">IIBBBBB",wd,ht,8,6,0,0,0))+ch(b"IDAT",zlib.compress(raw))+ch(b"IEND",b""))
def clamp(v): return max(0,min(255,int(v)))
def noisy(base,var,seed,extra=None):
    rnd=random.Random(seed); g=[[rnd.uniform(-var,var) for _ in range(16)] for _ in range(16)]
    def f(x,y):
        d=g[y%16][x%16]; r,gc,b=base
        if extra: r,gc,b,d2=extra(x,y,r,gc,b); d+=d2
        return (clamp(r+d),clamp(gc+d*0.5),clamp(b+d*0.5),255)
    return f
T=f"{R}/assets/thegut/textures"
png(f"{T}/block/gut_flesh.png",16,16,noisy((150,50,60),22,1,lambda x,y,r,g,b:(r,g,b,-30 if (x*3+y*5)%11==0 else 0)))
png(f"{T}/block/gut_membrane.png",16,16,noisy((190,95,105),10,2,lambda x,y,r,g,b:(r,g,b,12 if y%4==0 else 0)))
png(f"{T}/block/gut_bone.png",16,16,noisy((215,205,175),12,3,lambda x,y,r,g,b:(r,g,b,-35 if x%8==0 or y%8==0 else 0)))
png(f"{T}/block/gut_marrow.png",16,16,noisy((235,125,45),25,4,lambda x,y,r,g,b:(r,g,b,30 if (x-8)**2+(y-8)**2<18 else 0)))
def portal(x,y):
    f=y//16; yy=y%16; v=(x+yy*2+f*4)%16
    return (90+v*6,10+f*8,40+v*3,200)
png(f"{T}/block/gut_portal.png",16,64,portal)
w(f"{T}/block/gut_portal.png.mcmeta",{"animation":{"frametime":6}})
key=set([(x,2) for x in range(2,7)]+[(2,y) for y in range(2,6)]+[(6,y) for y in range(2,6)]+[(x,5) for x in range(2,7)]+[(4,y) for y in range(6,14)]+[(5,11),(6,11),(5,13),(6,13)])
png(f"{T}/item/gut_key.png",16,16,lambda x,y:(225,215,185,255) if (x,y) in key else (0,0,0,0))
blocks={"gut_flesh":"Gut Flesh","gut_membrane":"Gut Membrane","gut_bone":"Gut Bone","gut_marrow":"Marrow","gut_portal":"Gut Portal"}
lang={"item.thegut.gut_key":"Gut Key","item.thegut.gut_key.tooltip":"Opens a way into the Gut.",
 "thegut.gl.notfound":"Golden Light was not found, so the Gut uses its own default textures. Install Golden Light on Steam, or set goldenLightPath in config/thegut.json.",
 "thegut.gl.extracting":"Importing textures from your Golden Light install. This happens once and nothing leaves your PC.",
 "thegut.gl.ready":"Golden Light content imported. Textures update on the next resource reload.",
 "thegut.gl.failed":"Importing from Golden Light failed, so default Gut textures are used. See logs/thegut.log.",
 "thegut.firstjoin":"You have a Gut Key. Build a bone-block frame, 2 wide and 3 tall inside, and use the key on its base."}
for b,n in blocks.items():
    lang[f"block.thegut.{b}"]=n
    w(f"{R}/assets/thegut/blockstates/{b}.json",{"variants":{"":{"model":f"thegut:block/{b}"}}})
    w(f"{R}/assets/thegut/models/block/{b}.json",{"parent":"minecraft:block/cube_all","textures":{"all":f"thegut:block/{b}"}})
    w(f"{R}/assets/thegut/models/item/{b}.json",{"parent":f"thegut:block/{b}"})
    if b!="gut_portal":
        w(f"{R}/data/thegut/loot_tables/blocks/{b}.json",{"type":"minecraft:block","pools":[{"rolls":1,"entries":[{"type":"minecraft:item","name":f"thegut:{b}"}],"conditions":[{"condition":"minecraft:survives_explosion"}]}]})
w(f"{R}/assets/thegut/models/item/gut_key.json",{"parent":"minecraft:item/generated","textures":{"layer0":"thegut:item/gut_key"}})
w(f"{R}/assets/thegut/lang/en_us.json",lang)
w(f"{R}/assets/thegut/sounds.json",{
 "ambient.gut_loop":{"sounds":[{"name":"minecraft:ambient.crimson_forest.loop","type":"event"}]},
 "ambient.gut_mood":{"sounds":[{"name":"minecraft:ambient.crimson_forest.mood","type":"event"}]}})
w(f"{R}/data/thegut/recipes/gut_key.json",{"type":"minecraft:crafting_shapeless","ingredients":[{"item":"minecraft:bone_block"},{"item":"minecraft:rotten_flesh"},{"item":"minecraft:rotten_flesh"},{"item":"minecraft:spider_eye"}],"result":{"item":"thegut:gut_key","count":1}})
# worldgen
w(f"{R}/data/thegut/dimension_type/gut.json",{"ultrawarm":False,"natural":False,"piglin_safe":False,"respawn_anchor_works":False,"bed_works":False,"has_raids":False,"has_skylight":False,"has_ceiling":True,"coordinate_scale":1.0,"ambient_light":0.1,"logical_height":128,"fixed_time":18000,"effects":"thegut:gut","infiniburn":"minecraft:infiniburn_nether"})
w(f"{R}/data/thegut/dimension/gut.json",{"type":"thegut:gut","generator":{"type":"minecraft:noise","seed":0,"settings":"thegut:gut","biome_source":{"type":"minecraft:fixed","biome":"thegut:gut_cavity"}}})
w(f"{R}/data/thegut/worldgen/noise_settings/gut.json",{"bedrock_roof_position":0,"bedrock_floor_position":0,"sea_level":32,"disable_mob_generation":True,"noise":{"density_factor":0.0,"density_offset":0.019921875,"simplex_surface_noise":False,"random_density_offset":False,"island_noise_override":False,"amplified":False,"size_horizontal":1,"size_vertical":2,"height":128,"sampling":{"xz_scale":1.0,"y_scale":3.0,"xz_factor":80.0,"y_factor":60.0},"top_slide":{"target":120,"size":3,"offset":0},"bottom_slide":{"target":320,"size":4,"offset":-1}},"default_block":{"Name":"thegut:gut_flesh"},"default_fluid":{"Name":"minecraft:water","Properties":{"level":"0"}},"structures":{"structures":{}}})
def ore(name,block,size,count):
    inner={"type":"minecraft:ore","config":{"target":{"predicate_type":"minecraft:block_match","block":"thegut:gut_flesh"},"state":{"Name":f"thegut:{block}"},"size":size}}
    def dec(f,t,c): return {"type":"minecraft:decorated","config":{"feature":f,"decorator":{"type":t,"config":c}}}
    f=dec(dec(dec(inner,"minecraft:range",{"bottom_offset":0,"top_offset":0,"maximum":120}),"minecraft:square",{}),"minecraft:count",{"count":count})
    w(f"{R}/data/thegut/worldgen/configured_feature/{name}.json",f)
ore("marrow_vein","gut_marrow",10,40); ore("bone_vein","gut_bone",14,30)
feat=[[] for _ in range(10)]; feat[6]=["thegut:marrow_vein","thegut:bone_vein"]
w(f"{R}/data/thegut/worldgen/biome/gut_cavity.json",{"precipitation":"none","category":"nether","depth":0.1,"scale":0.2,"temperature":0.9,"downfall":0.0,
 "effects":{"sky_color":0x3a0d12,"fog_color":0x3a0d12,"water_color":0x5b7a2a,"water_fog_color":0x2f3d12,"loop_sound":"thegut:ambient.gut_loop","mood_sound":{"sound":"thegut:ambient.gut_mood","tick_delay":6000,"block_search_extent":8,"offset":2.0}},
 "surface_builder":{"type":"minecraft:default","config":{"top_material":{"Name":"thegut:gut_membrane"},"under_material":{"Name":"thegut:gut_flesh"},"underwater_material":{"Name":"thegut:gut_flesh"}}},
 "carvers":{"air":["minecraft:nether_cave"]},"features":feat,"starts":[],
 "spawners":{k:[] for k in ["monster","creature","ambient","water_creature","water_ambient","misc"]},"spawn_costs":{}})
w(f"{R}/fabric.mod.json",{"schemaVersion":1,"id":"thegut","version":"0.1.0","name":"The Gut","description":"A flesh-and-bone dimension in Minecraft, with optional textures imported locally from your own Golden Light install.","environment":"*","entrypoints":{},"depends":{"fabricloader":">=0.11.3","fabric":"*","minecraft":"1.16.5","java":">=8"},"custom":{"thegut:status":"resources only; Java entrypoints not written yet"}})
w("gradle.properties","# UNVERIFIED versions, confirm against fabricmc.net/develop before building\nminecraft_version=1.16.5\nyarn_mappings=1.16.5+build.10\nloader_version=0.11.3\nfabric_version=0.42.0+1.16\nmod_version=0.1.0\n")
print("ok")
